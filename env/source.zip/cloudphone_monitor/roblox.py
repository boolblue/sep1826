from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from . import android


def _read_json_root(path: Path) -> dict[str, Any] | None:
    result = android.run_root(["cat", str(path)], timeout=10)
    if result.returncode != 0 or not result.stdout:
        return None
    try:
        value = json.loads(result.stdout)
        return value if isinstance(value, dict) else None
    except json.JSONDecodeError:
        return None


def _read_prefs_root(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    result = android.run_root(["cat", str(path)], timeout=10)
    if result.returncode != 0 or not result.stdout:
        return values

    try:
        root = ET.fromstring(result.stdout)
    except ET.ParseError:
        return values

    for entry in root:
        name = entry.get("name")
        if not name:
            continue
        if entry.get("value") is not None:
            values[name] = entry.get("value", "")
        else:
            values[name] = entry.text or ""
    return values


def _candidate_roots(package: str) -> list[Path]:
    roots = [
        Path(f"/data/user/0/{package}"),
        Path(f"/data/data/{package}"),
    ]

    # Root can enumerate Android multi-user containers even when Termux itself cannot.
    result = android.run_root(
        [
            "find", "/data/user", "-mindepth", "2", "-maxdepth", "2",
            "-type", "d", "-name", package,
        ],
        timeout=15,
    )
    if result.returncode == 0:
        for line in result.stdout.splitlines():
            line = line.strip()
            if line:
                roots.append(Path(line))

    unique: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        text = str(root)
        if text not in seen:
            seen.add(text)
            unique.append(root)
    return unique


def _parse_store(root: Path) -> tuple[dict[str, Any], dict[str, str]]:
    storage = root / "files/appData/LocalStorage/appStorage.json"
    prefs = root / "shared_prefs/prefs.xml"
    return _read_json_root(storage) or {}, _read_prefs_root(prefs)


def _nested(store: dict[str, Any], key: str) -> dict[str, Any]:
    raw = store.get(key)
    if not raw:
        return {}
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            return {}
    return {}


def _looks_like_username(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    value = value.strip()
    if not value or len(value) > 80:
        return False
    return not value.startswith("http") and not value.startswith("{") and not value.startswith("[")


def get_account(package: str) -> dict[str, Any]:
    # Best-effort local extraction. Do not return credential/token fields.
    best: dict[str, Any] = {}
    for root in _candidate_roots(package):
        store, prefs = _parse_store(root)
        if not store and not prefs:
            continue

        user_id = store.get("UserId") or prefs.get("userid_long") or prefs.get("userId")
        username = store.get("Username") or prefs.get("username")
        display_name = store.get("DisplayName") or prefs.get("displayName")

        hydration = _nested(store, "PlayerHydrationBlob")
        if not username:
            username = hydration.get("username")
        if not display_name:
            display_name = hydration.get("displayName")
        if not user_id:
            user_id = hydration.get("userId") or hydration.get("userID")

        candidate = {
            "user_id": str(user_id) if user_id is not None else None,
            "username": str(username) if _looks_like_username(username) else None,
            "display_name": str(display_name) if _looks_like_username(display_name) else None,
            "source": str(root),
        }

        score = sum(1 for key in ("user_id", "username", "display_name") if candidate[key])
        if score > sum(1 for key in ("user_id", "username", "display_name") if best.get(key)):
            best = candidate
        if score == 3:
            return best

    if best:
        return best

    # UI fallback. This may only expose a username if the current app screen renders it.
    ui = android.run_root(
        "uiautomator dump /data/local/tmp/cloudphone-monitor-ui.xml >/dev/null 2>&1; cat /data/local/tmp/cloudphone-monitor-ui.xml",
        timeout=15,
    )
    xml = ui.stdout
    texts = re.findall(r'text="([^"]+)"', xml)
    for text in texts:
        if re.fullmatch(r"[A-Za-z0-9_]{3,20}", text) and text.lower() not in {"roblox", "settings", "search", "home", "play"}:
            return {"user_id": None, "username": text, "display_name": None, "source": "uiautomator"}

    return {"user_id": None, "username": None, "display_name": None, "source": None}
