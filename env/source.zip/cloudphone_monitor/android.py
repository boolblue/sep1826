from __future__ import annotations

import os
import re
import subprocess
import time
from pathlib import Path
from typing import Sequence


class AndroidCommandError(RuntimeError):
    pass


def _shell_quote(value: str) -> str:
    return "'" + value.replace("'", "'\\''") + "'"


def run_root(command: str | Sequence[str], timeout: int = 15, check: bool = False) -> subprocess.CompletedProcess[str]:
    if isinstance(command, str):
        shell_command = command
    else:
        shell_command = " ".join(_shell_quote(item) for item in command)

    result = subprocess.run(
        ["su", "-c", shell_command],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )
    if check and result.returncode != 0:
        raise AndroidCommandError(
            result.stderr.strip() or result.stdout.strip() or f"root command failed: {shell_command}"
        )
    return result


def root_available() -> bool:
    try:
        result = run_root("id", timeout=5)
        return result.returncode == 0 and "uid=0" in result.stdout
    except (OSError, subprocess.SubprocessError):
        return False


def package_installed(package: str) -> bool:
    result = run_root(["pm", "path", package], timeout=10)
    return result.returncode == 0 and "package:" in result.stdout


def process_pids(process_name: str, package: str | None = None) -> list[int]:
    names: list[str] = []
    for name in (process_name, package):
        if name and name not in names:
            names.append(name)

    pids: set[int] = set()
    for name in names:
        result = run_root(["pidof", name], timeout=5)
        if result.returncode == 0:
            for token in result.stdout.split():
                try:
                    pids.add(int(token))
                except ValueError:
                    pass
    return sorted(pids)


def process_running(process_name: str, package: str | None = None) -> bool:
    return bool(process_pids(process_name, package))


def _component_from_line(line: str) -> tuple[str, str] | None:
    matches = list(re.finditer(r"\b([A-Za-z0-9_.$]+)/([A-Za-z0-9_.$]+)\b", line))
    if not matches:
        return None
    match = matches[-1]
    return match.group(1), match.group(2)


def foreground_info() -> dict[str, str]:
    """Return the currently resumed/focused Android component plus best-effort intent data."""
    commands = [
        "dumpsys activity activities",
        "dumpsys activity top",
        "dumpsys window windows",
        "cmd activity get-top-activity",
    ]
    for command in commands:
        result = run_root(command, timeout=10)
        text = result.stdout + "\n" + result.stderr
        for line in text.splitlines():
            if not any(marker in line for marker in (
                "mResumedActivity:", "topResumedActivity=", "ResumedActivity:",
                "mCurrentFocus=", "mFocusedApp=", "Top activity:",
            )):
                continue
            component = _component_from_line(line)
            if component:
                data = ""
                match = re.search(r'\bdat=([^}\s]+)', line)
                if match:
                    data = match.group(1)
                return {"package": component[0], "activity": component[1], "data": data}
    return {"package": "unknown", "activity": "unknown", "data": ""}

def _looks_like_successful_start(text: str) -> bool:
    lowered = text.lower()
    failure_markers = (
        "error:",
        "exception:",
        "does not exist",
        "permission denial",
        "unable to resolve intent",
        "activitynotfoundexception",
    )
    return not any(marker in lowered for marker in failure_markers)


def launch_package(
    package: str,
    launcher_activity: str = "",
    method: str = "explicit_activity",
    timeout: int = 20,
) -> tuple[bool, str]:
    method = method.lower()
    attempts: list[str] = []

    def do(command: list[str]) -> bool:
        result = run_root(command, timeout=timeout)
        output = (result.stdout + "\n" + result.stderr).strip()
        attempts.append(output)
        return result.returncode == 0 and _looks_like_successful_start(output)

    if method in {"explicit_activity", "auto"} and launcher_activity:
        component = launcher_activity if "/" in launcher_activity else f"{package}/{launcher_activity}"
        if do(["/system/bin/am", "start", "-W", "-n", component]):
            return True, "\n---\n".join(attempts)[-1200:]

    if method in {"explicit_activity", "am_start_package", "auto"}:
        if do([
            "/system/bin/am", "start", "-W",
            "-a", "android.intent.action.MAIN",
            "-c", "android.intent.category.LAUNCHER",
            "-p", package,
        ]):
            return True, "\n---\n".join(attempts)[-1200:]

    if method in {"explicit_activity", "monkey", "am_start_package", "auto"}:
        if do(["/system/bin/monkey", "-p", package, "-c", "android.intent.category.LAUNCHER", "1"]):
            return True, "\n---\n".join(attempts)[-1200:]

    return False, "\n---\n".join(attempts)[-1200:]



def join_game(game_id: str, timeout: int = 15) -> tuple[bool, str]:
    """Ask the installed Roblox client to open a place by placeId."""
    uri = f"roblox://placeId={game_id}"
    result = run_root([
        "/system/bin/am", "start", "-W",
        "-a", "android.intent.action.VIEW",
        "-d", uri,
    ], timeout=timeout)
    output = (result.stdout + "\n" + result.stderr).strip()
    return result.returncode == 0 and _looks_like_successful_start(output), output[-1200:]

def wait_for_foreground(package: str, timeout_seconds: float = 10.0) -> dict[str, str]:
    deadline = time.monotonic() + max(0.5, timeout_seconds)
    latest = {"package": "unknown", "activity": "unknown", "data": ""}
    while time.monotonic() < deadline:
        latest = foreground_info()
        if latest.get("package") == package:
            return latest
        time.sleep(0.5)
    return latest


def app_state(package: str, process_name: str) -> dict[str, object]:
    foreground = foreground_info()
    pids = process_pids(process_name, package)
    process_exists = bool(pids)
    is_foreground = foreground.get("package") == package

    return {
        "process_exists": process_exists,
        "process_pids": pids,
        "foreground": is_foreground,
        "foreground_package": foreground.get("package"),
        "foreground_activity": foreground.get("activity"),
        "foreground_data": foreground.get("data", ""),
        "running": is_foreground,
    }


def screen_on() -> bool | None:
    result = run_root("dumpsys power", timeout=10)
    text = result.stdout + "\n" + result.stderr
    matches = re.findall(r"(?:mWakefulness=|Display Power: state=)([A-Za-z]+)", text)
    if matches:
        state = matches[-1].upper()
        if state in {"AWAKE", "ON"}:
            return True
        if state in {"ASLEEP", "OFF", "DOZING"}:
            return False
    return None


def battery_info() -> dict[str, object]:
    result = run_root("dumpsys battery", timeout=10)
    text = result.stdout + "\n" + result.stderr

    def find_int(*names: str) -> int | None:
        for name in names:
            match = re.search(rf"^\s*{re.escape(name)}\s*:\s*(-?\d+)", text, flags=re.MULTILINE)
            if match:
                return int(match.group(1))
        return None

    level = find_int("level")
    temp_tenths = find_int("temperature")
    status = find_int("status")
    plugged = find_int("plugged")

    return {
        "level_percent": level,
        "temperature_c": round(temp_tenths / 10.0, 1) if temp_tenths is not None else None,
        "status_code": status,
        "plugged_code": plugged,
    }


def uptime_seconds() -> float | None:
    try:
        with open("/proc/uptime", "r", encoding="ascii") as handle:
            return float(handle.read().split()[0])
    except (OSError, ValueError, IndexError):
        return None


def storage_info(path: str = "/data") -> dict[str, object]:
    try:
        stat = os.statvfs(path)
        total = stat.f_blocks * stat.f_frsize
        free = stat.f_bavail * stat.f_frsize
        used = total - free
        return {
            "path": path,
            "total_bytes": total,
            "used_bytes": used,
            "free_bytes": free,
            "used_percent": round((used / total) * 100, 2) if total else None,
        }
    except OSError:
        return {"path": path, "total_bytes": None, "used_bytes": None, "free_bytes": None, "used_percent": None}


def thermal_zones() -> list[dict[str, object]]:
    zones: list[dict[str, object]] = []
    result = run_root(
        'for f in /sys/class/thermal/thermal_zone*/temp; do [ -f "$f" ] && echo "$f=$(cat "$f")"; done',
        timeout=10,
    )
    if result.returncode != 0:
        return zones

    for line in result.stdout.splitlines():
        if "=" not in line:
            continue
        name, raw = line.split("=", 1)
        try:
            milli_c = int(raw.strip())
        except ValueError:
            continue
        zones.append({"zone": Path(name).parent.name, "celsius": round(milli_c / 1000.0, 1)})
    return zones


def screenshot(output_path: str, max_bytes: int = 18_000_000) -> tuple[bool, str]:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    result = run_root(["/system/bin/screencap", "-p", str(path)], timeout=20)
    if result.returncode != 0 or not path.exists():
        return False, (result.stdout + result.stderr).strip()

    run_root(["chmod", "0644", str(path)], timeout=5)

    size = path.stat().st_size
    if size <= 0:
        return False, "screencap produced an empty file"
    if size > max_bytes:
        return False, f"screenshot is {size} bytes, over configured limit {max_bytes}"

    return True, ""
