from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class AppConfig:
    package: str
    process_name: str
    launcher_activity: str
    auto_launch: bool
    launch_grace_seconds: int
    launch_timeout_seconds: int
    launch_method: str
    game_id: str
    game_activity: str
    auto_join_game: bool
    watchdog_interval_seconds: int


@dataclass(frozen=True)
class MonitorConfig:
    interval_seconds: int
    cpu_sample_seconds: float
    request_timeout_seconds: int
    screenshot_enabled: bool
    max_screenshot_bytes: int


@dataclass(frozen=True)
class DiscordConfig:
    webhook_url: str
    webhook_url_env: str
    username: str
    avatar_url: str
    content: str
    mention: str


@dataclass(frozen=True)
class RuntimeConfig:
    temp_dir: str
    log_file: str


@dataclass(frozen=True)
class Config:
    app: AppConfig
    monitor: MonitorConfig
    discord: DiscordConfig
    runtime: RuntimeConfig


def _require(data: dict[str, Any], key: str, section: str) -> Any:
    if key not in data:
        raise ValueError(f"Missing config key: [{section}] {key}")
    return data[key]


def load_config(path: str | Path = "config.json") -> Config:
    path = Path(path)
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)

    app_raw = data.get("app", {})
    monitor_raw = data.get("monitor", {})
    discord_raw = data.get("discord", {})
    runtime_raw = data.get("runtime", {})

    package = str(_require(app_raw, "package", "app"))
    process_name = str(app_raw.get("process_name") or package)
    launcher_activity = str(app_raw.get("launcher_activity") or "").strip()
    launch_method = str(app_raw.get("launch_method", "explicit_activity")).lower()
    if launch_method not in {"explicit_activity", "monkey", "am_start_package", "auto"}:
        raise ValueError("app.launch_method must be 'explicit_activity', 'monkey', 'am_start_package', or 'auto'")

    interval = int(monitor_raw.get("interval_seconds", 300))
    if interval < 5:
        raise ValueError("monitor.interval_seconds must be >= 5")

    return Config(
        app=AppConfig(
            package=package,
            process_name=process_name,
            launcher_activity=launcher_activity,
            auto_launch=bool(app_raw.get("auto_launch", True)),
            launch_grace_seconds=int(app_raw.get("launch_grace_seconds", 8)),
            launch_timeout_seconds=int(app_raw.get("launch_timeout_seconds", 20)),
            launch_method=launch_method,
            game_id=str(app_raw.get("game_id", "1730877806")),
            game_activity=str(app_raw.get("game_activity", "com.roblox.client.ActivityNativeMain")),
            auto_join_game=bool(app_raw.get("auto_join_game", True)),
            watchdog_interval_seconds=max(2, int(app_raw.get("watchdog_interval_seconds", 5))),
        ),
        monitor=MonitorConfig(
            interval_seconds=interval,
            cpu_sample_seconds=float(monitor_raw.get("cpu_sample_seconds", 1.0)),
            request_timeout_seconds=int(monitor_raw.get("request_timeout_seconds", 20)),
            screenshot_enabled=bool(monitor_raw.get("screenshot_enabled", True)),
            max_screenshot_bytes=int(monitor_raw.get("max_screenshot_bytes", 18_000_000)),
        ),
        discord=DiscordConfig(
            webhook_url=str(discord_raw.get("webhook_url", "")),
            webhook_url_env=str(discord_raw.get("webhook_url_env", "CLOUDPHONE_DISCORD_WEBHOOK")),
            username=str(discord_raw.get("username", "CloudPhone Monitor")),
            avatar_url=str(discord_raw.get("avatar_url", "")),
            content=str(discord_raw.get("content", "")),
            mention=str(discord_raw.get("mention", "")),
        ),
        runtime=RuntimeConfig(
            temp_dir=str(runtime_raw.get("temp_dir", "/data/local/tmp/cloudphone-monitor")),
            log_file=str(runtime_raw.get("log_file", "monitor.log")),
        ),
    )


def resolve_webhook_url(config: DiscordConfig) -> str:
    return config.webhook_url.strip() or os.environ.get(config.webhook_url_env, "").strip()
