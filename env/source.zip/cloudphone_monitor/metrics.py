from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass
from typing import Any

from . import android


@dataclass
class ProcStat:
    total: int
    idle: int


def _read_cpu_stat() -> ProcStat | None:
    first = ""
    try:
        result = android.run_root("head -n 1 /proc/stat", timeout=5)
        first = result.stdout.strip()
    except Exception:
        pass
    if not first:
        try:
            with open("/proc/stat", "r", encoding="ascii") as handle:
                first = handle.readline().strip()
        except OSError:
            return None

    fields = first.split()
    if not fields or fields[0] != "cpu" or len(fields) < 5:
        return None
    try:
        values = [int(value) for value in fields[1:]]
    except ValueError:
        return None

    idle = values[3] + (values[4] if len(values) > 4 else 0)
    return ProcStat(total=sum(values), idle=idle)


def _cpu_usage_from_top() -> float | None:
    try:
        result = android.run_root(["/system/bin/top", "-n", "1", "-b"], timeout=8)
        text = result.stdout + "\n" + result.stderr
    except Exception:
        return None

    for line in text.splitlines():
        if "%idle" in line.lower():
            total_match = re.search(r"(\d+(?:\.\d+)?)%cpu", line, flags=re.IGNORECASE)
            idle_match = re.search(r"(\d+(?:\.\d+)?)%idle", line, flags=re.IGNORECASE)
            if total_match and idle_match:
                total = float(total_match.group(1))
                idle = float(idle_match.group(1))
                if total > 0:
                    return round(max(0.0, min(100.0, (total - idle) / total * 100.0)), 2)

            idle_only = re.search(r"(\d+(?:\.\d+)?)%\s*idle", line, flags=re.IGNORECASE)
            if idle_only:
                return round(max(0.0, min(100.0, 100.0 - float(idle_only.group(1)))), 2)

    return None


def cpu_usage_percent(sample_seconds: float = 1.0) -> float | None:
    before = _read_cpu_stat()
    if before is not None:
        time.sleep(max(0.1, sample_seconds))
        after = _read_cpu_stat()
        if after is not None:
            total_delta = after.total - before.total
            idle_delta = after.idle - before.idle
            if total_delta > 0:
                value = (total_delta - idle_delta) / total_delta * 100.0
                return round(max(0.0, min(100.0, value)), 2)

    return _cpu_usage_from_top()


def memory_info() -> dict[str, Any]:
    data: dict[str, int] = {}
    try:
        with open("/proc/meminfo", "r", encoding="ascii") as handle:
            for line in handle:
                parts = line.split(":", 1)
                if len(parts) != 2:
                    continue
                key, rest = parts
                match = re.search(r"(\d+)", rest)
                if match:
                    data[key] = int(match.group(1)) * 1024
    except OSError:
        return {"total_bytes": None, "available_bytes": None, "used_bytes": None, "used_percent": None}

    total = data.get("MemTotal")
    available = data.get("MemAvailable")
    used = total - available if total is not None and available is not None else None
    return {
        "total_bytes": total,
        "available_bytes": available,
        "used_bytes": used,
        "used_percent": round((used / total) * 100.0, 2) if used is not None and total else None,
    }


def load_average() -> list[float] | None:
    # Some Termux CPython builds do not expose os.getloadavg(). Android still
    # provides the Linux load-average file, so read it directly instead.
    readers: list[str] = []
    try:
        result = android.run_root("cat /proc/loadavg", timeout=5)
        readers.append(result.stdout)
    except Exception:
        pass
    try:
        with open("/proc/loadavg", "r", encoding="ascii") as handle:
            readers.append(handle.read())
    except OSError:
        pass

    for raw in readers:
        fields = raw.split()
        if len(fields) < 3:
            continue
        try:
            return [round(float(fields[0]), 2), round(float(fields[1]), 2), round(float(fields[2]), 2)]
        except ValueError:
            continue
    return None


def _read_process_ticks(pid: int) -> int | None:
    result = android.run_root(["cat", f"/proc/{pid}/stat"], timeout=5)
    if result.returncode != 0 or not result.stdout.strip():
        return None

    text = result.stdout.strip()
    close_paren = text.rfind(")")
    if close_paren < 0:
        return None
    fields = text[close_paren + 2 :].split()
    if len(fields) < 13:
        return None

    # After comm: state=0, ppid=1, ... utime=11, stime=12.
    return int(fields[11]) + int(fields[12])


def process_cpu_percent(pid: int) -> float | None:
    try:
        proc1 = _read_process_ticks(pid)
        system1 = _read_cpu_stat()
        if proc1 is None or system1 is None:
            return None

        time.sleep(0.25)

        proc2 = _read_process_ticks(pid)
        system2 = _read_cpu_stat()
        if proc2 is None or system2 is None:
            return None

        proc_delta = proc2 - proc1
        total_delta = system2.total - system1.total
        if proc_delta < 0 or total_delta <= 0:
            return None

        cpu_count = os.cpu_count() or 1
        return round((proc_delta / total_delta) * cpu_count * 100.0, 2)
    except (OSError, ValueError, IndexError, TypeError):
        return None


def collect_system_metrics(cpu_sample_seconds: float, package: str, process_name: str) -> dict[str, Any]:
    pids = android.process_pids(process_name, package)
    launcher_pid = pids[0] if pids else None

    return {
        "cpu_percent": cpu_usage_percent(cpu_sample_seconds),
        "memory": memory_info(),
        "load_average": load_average(),
        "launcher_process_cpu_percent": process_cpu_percent(launcher_pid) if launcher_pid else None,
        "launcher_pid": launcher_pid,
        "uptime_seconds": android.uptime_seconds(),
        "battery": android.battery_info(),
        "storage": android.storage_info("/data"),
        "thermal_zones": android.thermal_zones(),
        "screen_on": android.screen_on(),
        "foreground": android.foreground_info(),
    }
