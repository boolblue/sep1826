from __future__ import annotations

import logging
import signal
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import android
from .config import Config, resolve_webhook_url
from .discord_reporter import DiscordReporter
from .metrics import collect_system_metrics
from .roblox import get_account


class CloudPhoneMonitor:
    def __init__(self, config: Config):
        self.config = config
        self.logger = logging.getLogger("cloudphone-monitor")
        self.runtime_dir = self._select_runtime_dir(config.runtime.temp_dir)
        self.stop_event = threading.Event()
        self._install_signal_handlers()

    def _install_signal_handlers(self) -> None:
        def handle_signal(signum, _frame):
            self.logger.info("Received %s; stopping monitor...", signal.Signals(signum).name)
            self.stop_event.set()
            android.STOP_EVENT.set()

        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)

    @staticmethod
    def _select_runtime_dir(configured: str) -> Path:
        """Select a directory writable by the non-root Termux Python process.

        Android system temp locations such as /data/local/tmp may be writable by
        `su -c` commands but are not necessarily writable by the Termux UID.
        Python-owned files therefore live under Termux HOME by default/fallback.
        """
        preferred = Path(configured).expanduser()
        # `/data/local/tmp` is a system location: rooted `su -c` commands can
        # write there, but the normal Termux Python UID commonly cannot. Keep
        # Python-owned files out of that location even when the builder itself
        # happens to run as root.
        if str(preferred) == "/data/local/tmp" or str(preferred).startswith("/data/local/tmp/"):
            preferred = Path.home() / ".cloudphone-monitor"

        try:
            preferred.mkdir(parents=True, exist_ok=True)
            probe = preferred / ".write_test"
            probe.write_bytes(b"")
            probe.unlink(missing_ok=True)
            return preferred
        except (OSError, PermissionError):
            fallback = Path.home() / ".cloudphone-monitor"
            fallback.mkdir(parents=True, exist_ok=True)
            return fallback

    def _launch_and_wait(self, package: str) -> tuple[bool, str, dict[str, str]]:
        activity = self.config.app.launcher_activity
        self.logger.info(
            "Launching %s using launcher activity %s",
            package,
            activity or "auto-resolve",
        )

        ok, launch_output = android.launch_package(
            package=package,
            launcher_activity=activity,
            method=self.config.app.launch_method,
            timeout=self.config.app.launch_timeout_seconds,
        )

        foreground = {"package": "unknown", "activity": "unknown"}
        if ok:
            foreground = android.wait_for_foreground(
                package,
                timeout_seconds=max(1, self.config.app.launch_grace_seconds),
            )

        return ok and foreground.get("package") == package, launch_output, foreground

    def _join_game(self) -> bool:
        game_id = self.config.app.game_id
        if not game_id:
            return False
        self.logger.info("Joining Roblox game %s", game_id)
        ok, output = android.join_game(game_id, timeout=self.config.app.launch_timeout_seconds)
        if not ok:
            self.logger.warning("Game join command failed: %s", output)
        return ok

    def _game_state(self, app_state: dict[str, Any]) -> dict[str, Any]:
        activity = str(app_state.get("foreground_activity") or "")
        data = str(app_state.get("foreground_data") or "")
        package = str(app_state.get("foreground_package") or "")
        target_activity = self.config.app.game_activity
        target_game = self.config.app.game_id

        place_match = None
        match = __import__("re").search(r"(?:placeId|placeid)=(\d+)", data)
        if match:
            place_match = match.group(1)

        active_by_activity = bool(target_activity and activity.endswith(target_activity))
        active_by_place = bool(target_game and place_match == target_game)

        # ActivityNativeMain is also used by the Roblox home/menu on this client,
        # so it is NOT sufficient evidence that the user is inside the game.
        # A positive placeId match is required.
        in_game = package == self.config.app.package and active_by_place
        return {
            "in_game": in_game,
            "place_id": place_match,
            "activity_match": active_by_activity,
            "place_match": active_by_place,
            "foreground_data": data,
        }

    def watchdog_once(self) -> None:
        package = self.config.app.package
        state = android.app_state(package, self.config.app.process_name)

        if not state["running"]:
            self.logger.warning("Watchdog: %s is not open; launching instance", package)
            ok, output, _ = self._launch_and_wait(package)
            state = android.app_state(package, self.config.app.process_name)
            if not ok or not state["running"]:
                self.logger.error("Watchdog: failed to open %s: %s", package, output[-500:])
                return

        if self.config.app.auto_join_game:
            game = self._game_state(state)
            self.logger.info(
                "Game watchdog: in_game=%s place_id=%s activity=%s activity_match=%s data=%s",
                game["in_game"],
                game.get("place_id"),
                state.get("foreground_activity"),
                game.get("activity_match"),
                game.get("foreground_data"),
            )
            if not game["in_game"]:
                self.logger.warning(
                    "Watchdog: Roblox is open but game %s is not confirmed active; joining game",
                    self.config.app.game_id,
                )
                self._join_game()

    def watchdog_loop(self) -> None:
        interval = self.config.app.watchdog_interval_seconds
        self.logger.info("Watchdog started (every %ss)", interval)
        while not self.stop_event.is_set():
            try:
                self.watchdog_once()
            except Exception:
                self.logger.exception("Watchdog cycle failed")
            self.stop_event.wait(interval)
        self.logger.info("Watchdog stopped")

    def ensure_launcher(self) -> dict[str, Any]:
        package = self.config.app.package
        process = self.config.app.process_name
        installed = android.package_installed(package)

        if not installed:
            return {
                "package": package,
                "installed": False,
                "running": False,
                "process_exists": False,
                "process_pids": [],
                "foreground": False,
                "foreground_package": "unknown",
                "foreground_activity": "unknown",
                "launch_attempted": False,
                "launch_output": "package is not installed",
            }

        state = android.app_state(package, process)
        launch_attempted = False
        launch_output = ""

        if not state["running"] and self.config.app.auto_launch:
            launch_attempted = True
            ok, launch_output, _foreground = self._launch_and_wait(package)
            state = android.app_state(package, process)

            if ok and not state["running"]:
                time.sleep(1.0)
                state = android.app_state(package, process)

            if not state["running"]:
                self.logger.warning(
                    "Launch did not bring %s to foreground; foreground=%s/%s output=%s",
                    package,
                    state["foreground_package"],
                    state["foreground_activity"],
                    launch_output[-500:],
                )

        return {
            "package": package,
            "installed": True,
            "running": bool(state["running"]),
            "process_exists": bool(state["process_exists"]),
            "process_pids": state["process_pids"],
            "foreground": bool(state["foreground"]),
            "foreground_package": state["foreground_package"],
            "foreground_activity": state["foreground_activity"],
            "launch_attempted": launch_attempted,
            "launch_output": launch_output[-800:],
        }

    def collect_report(self) -> tuple[dict[str, Any], Path | None]:
        app = self.ensure_launcher()
        metrics = collect_system_metrics(
            self.config.monitor.cpu_sample_seconds,
            self.config.app.package,
            self.config.app.process_name,
        )
        account = get_account(self.config.app.package)

        timestamp = datetime.now(timezone.utc).isoformat()
        payload = {
            "timestamp": timestamp,
            "app": app,
            "account": account,
            "metrics": metrics,
        }

        screenshot_path: Path | None = None
        if self.config.monitor.screenshot_enabled:
            self.runtime_dir.mkdir(parents=True, exist_ok=True)
            screenshot_path = self.runtime_dir / "latest.png"
            ok, detail = android.screenshot(
                str(screenshot_path),
                self.config.monitor.max_screenshot_bytes,
            )
            if not ok:
                self.logger.warning("Screenshot failed: %s", detail)
                screenshot_path = None

        return payload, screenshot_path

    def send(self, payload: dict[str, Any], screenshot_path: Path | None) -> None:
        webhook_url = resolve_webhook_url(self.config.discord)
        if not webhook_url:
            raise RuntimeError(
                "Discord webhook is not configured. Set discord.webhook_url or the configured environment variable."
            )

        reporter = DiscordReporter(
            webhook_url=webhook_url,
            username=self.config.discord.username,
            avatar_url=self.config.discord.avatar_url,
            timeout=self.config.monitor.request_timeout_seconds,
        )
        reporter.send_report(
            payload,
            screenshot_path=screenshot_path,
            content=self.config.discord.content,
            mention=self.config.discord.mention,
        )

    def run_once(self) -> None:
        payload, screenshot_path = self.collect_report()
        self.logger.info(
            "status package=%s running=%s foreground=%s/%s username=%s cpu=%s ram=%s load=%s",
            payload["app"]["package"],
            payload["app"]["running"],
            payload["app"]["foreground_package"],
            payload["app"]["foreground_activity"],
            payload["account"].get("username"),
            payload["metrics"].get("cpu_percent"),
            payload["metrics"].get("memory", {}).get("used_percent"),
            payload["metrics"].get("load_average"),
        )
        self.send(payload, screenshot_path)

    def loop(self) -> None:
        self.logger.info("CloudPhone Monitor starting for %s", self.config.app.package)
        if not android.root_available():
            raise RuntimeError("Root is not available to Termux (su -c id did not return uid=0).")

        import threading
        watchdog = threading.Thread(target=self.watchdog_loop, name="watchdog", daemon=True)
        watchdog.start()

        while not self.stop_event.is_set():
            started = time.monotonic()
            try:
                self.run_once()
                self.logger.info("Report sent successfully")
            except Exception:
                self.logger.exception("Monitor cycle failed")

            if self.stop_event.is_set():
                break
            elapsed = time.monotonic() - started
            delay = max(1.0, self.config.monitor.interval_seconds - elapsed)
            self.logger.info("Next cycle in %.1f seconds", delay)
            self.stop_event.wait(delay)

        self.stop_event.set()
        android.STOP_EVENT.set()
        watchdog.join(timeout=2.0)
        self.logger.info("CloudPhone Monitor stopped")
