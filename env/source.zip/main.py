from __future__ import annotations

import logging
import sys

from cloudphone_monitor.config import load_config
from cloudphone_monitor.monitor import CloudPhoneMonitor


def configure_logging(log_file: str) -> None:
    handlers = [logging.StreamHandler()]
    try:
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
    except OSError:
        pass

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=handlers,
    )


def main() -> int:
    config = load_config("config.json")
    configure_logging(config.runtime.log_file)

    monitor = CloudPhoneMonitor(config)
    try:
        monitor.loop()
    except KeyboardInterrupt:
        # Signal handlers normally convert Ctrl+C into a clean stop event.
        logging.getLogger("cloudphone-monitor").info("Stopped by user")
        return 0
    except Exception as exc:
        logging.getLogger("cloudphone-monitor").exception("Fatal error: %s", exc)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
