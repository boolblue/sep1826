# CloudPhone Monitor patch notes

## source.zip

### Patch: runtime directory permission fix

Fixed the crash:

```text
PermissionError: [Errno 13] Permission denied: '/data/local/tmp/cloudphone-monitor'
```

The Python process runs as the Termux user, while `/data/local/tmp` may only be writable through rooted `su -c` commands. Python now tests the configured runtime directory for write access and automatically falls back to:

```text
~/.cloudphone-monitor
```

The default `config.json` was also changed from `/data/local/tmp/cloudphone-monitor` to `~/.cloudphone-monitor`.

Privileged Android operations such as `screencap` continue to run through `su -c`; only Python-owned runtime files are moved to a Termux-writable directory.

### Previous fixes retained

- Launcher component: `free.nokaA/com.roblox.client.startup.LauncherAliasMain`
- Foreground detection based on current resumed/focused activity rather than process existence alone
- CPU usage from `/proc/stat` with `top` fallback
- Load average from `/proc/loadavg` instead of `os.getloadavg()`
- Roblox account extraction remains modular
- Discord webhook is supplied through configuration/environment rather than embedded in the source

### Run

```sh
python main.py
```
