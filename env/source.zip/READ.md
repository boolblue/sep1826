# Patch notes — game watchdog fix

## Problem fixed

`ActivityNativeMain` is not a reliable game-state signal on this Roblox client. The Roblox home/menu can use the same activity, so the previous watchdog could conclude that the user was already in the game and never send the join command.

## Changes

1. Game detection no longer treats `com.roblox.client.ActivityNativeMain` by itself as proof that the user is inside the configured game.
2. The watchdog now requires a matching `roblox://placeId=<game_id>` signal from the current Android foreground/top activity before reporting the game as active.
3. Android foreground parsing now checks multiple activity views and prefers a foreground/top activity carrying the Roblox place URI when available.
4. Added explicit watchdog diagnostics showing `in_game`, detected `place_id`, foreground activity, activity match, and foreground intent data.
5. If the configured game is not positively confirmed, the watchdog sends the configured `roblox://placeId=1730877806` join command.

## Important limitation

Android's activity name alone does not expose whether Roblox is displaying its home menu or a running experience. If this cloudphone build does not retain the place ID in the foreground intent after the game loads, the next patch will need a second positive signal (for example Roblox app state or screen/UI detection) rather than assuming `ActivityNativeMain` means the game is active.


## Patch 0.1.5 - graceful stop / Ctrl+C

Fixed a shutdown bug where the watchdog and blocking rooted Android commands could keep the process alive after Ctrl+C. The monitor now installs SIGINT/SIGTERM handlers, uses a shared stop event, replaces long sleeps with interruptible waits, and makes `su -c` polling commands terminate when shutdown is requested.

Expected behavior: press Ctrl+C once; the monitor logs `Received SIGINT; stopping monitor...`, stops the watchdog, and exits cleanly.


## Patch 0.1.6 - watchdog state machine + hard Ctrl+C shutdown

Fixed two major reliability problems from 0.1.5:

- Ctrl+C now interrupts the main loop immediately by raising `KeyboardInterrupt` from the signal handler, while the monitor performs cleanup in `finally`. A terminal-facing message is written directly to stderr so it does not depend on the logger.
- Rooted `su` commands no longer inherit Termux stdin. They run in their own process group, and shutdown/timeout kills the whole group so descendant processes cannot keep output pipes open.
- `start.sh` now uses unbuffered Python (`python -u`) and console logging is directed to stdout.
- The game watchdog now has a join-pending state. A successful game join suppresses additional join commands for 90 seconds by default, so Roblox can move through startup/loading without receiving repeated intents. Failed join commands use a shorter retry cooldown.
- Game detection now accepts either a matching `roblox://placeId=<game_id>` signal or a detected Roblox game runtime process such as `free.nokaA:glview`/`free.nokaA:game`.
- Foreground intent parsing now checks a multi-line ActivityRecord window because Android can print the component and `Intent`/`dat=` on different lines.
- The distributable archive is rebuilt without stale Python cache/temp files.

Roblox documents `roblox://placeId=<id>` as the direct-to-app deep-link format, so the watchdog keeps using that mechanism to request the target experience; this patch changes the state detection and retry behavior around it.
