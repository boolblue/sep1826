# Patch notes — game watchdog fix

## Problem fixed

`ActivityNativeMain` is not a reliable game-state signal on this Roblox client. The Roblox home/menu can use the same activity, so the previous watchdog could conclude that the user was already in the game and never send the join command.

## Changes

1. Game detection no longer treats `com.roblox.client.ActivityNativeMain` by itself as proof that the user is inside the configured game.
2. The watchdog now requires a matching `roblox://placeId=<game_id>` signal from the current Android foreground/top activity before reporting the game as active.
3. Android foreground parsing now checks multiple activity views and prefers a foreground/top activity carrying the Roblox place URI when available.
4. Added explicit watchdog diagnostics showing `in_game`, detected `place_id`, foreground activity, activity match, and foreground intent data.
5. If the configured game is not positively confirmed, the watchdog sends the configured `roblox://placeId=1730877806` join command.

## Important limitation

Android's activity name alone does not expose whether Roblox is displaying its home menu or a running experience. If this cloudphone build does not retain the place ID in the foreground intent after the game loads, the next patch will need a second positive signal (for example Roblox app state or screen/UI detection) rather than assuming `ActivityNativeMain` means the game is active.


## Patch 0.1.5 - graceful stop / Ctrl+C

Fixed a shutdown bug where the watchdog and blocking rooted Android commands could keep the process alive after Ctrl+C. The monitor now installs SIGINT/SIGTERM handlers, uses a shared stop event, replaces long sleeps with interruptible waits, and makes `su -c` polling commands terminate when shutdown is requested.

Expected behavior: press Ctrl+C once; the monitor logs `Received SIGINT; stopping monitor...`, stops the watchdog, and exits cleanly.
