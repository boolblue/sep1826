# CloudPhone Monitor — Patch: source

## New patch

1. After `free.nokaA` is launched, the monitor automatically opens Roblox game `1730877806` using `roblox://placeId=1730877806`.
2. Discord reports now attach the screenshot as `latest.png` and reference it from the embed's image field, so the screenshot is rendered inside the embed.
3. Added a continuous watchdog running every 5 seconds by default:
   - If `free.nokaA` is not the foreground app, it launches the configured launcher activity.
   - If Roblox is open but the configured game is not detected as active, it sends the game join intent for `1730877806`.
4. Game detection uses the configured Roblox game activity `com.roblox.client.ActivityNativeMain` and, when Android exposes it, the foreground intent's `placeId`.
5. Existing 5-minute Discord reporting remains separate from the watchdog.
6. Python-owned runtime files remain under the Termux user's home directory; privileged Android actions continue through `su`.

## Configuration

The relevant defaults are:

- package: `free.nokaA`
- launcher activity: `com.roblox.client.startup.LauncherAliasMain`
- game ID: `1730877806`
- game activity: `com.roblox.client.ActivityNativeMain`
- watchdog interval: `5` seconds
- report interval: `300` seconds
