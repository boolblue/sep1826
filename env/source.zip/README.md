# CloudPhone Monitor

Python/Termux monitor for a rooted Android cloudphone running the custom Roblox package `free.nokaA`.

## Current behavior

- Starts the configured Roblox launcher if the package is not foreground.
- Reports CPU, RAM, Android battery/thermal/storage/screen metrics, Roblox account data, and a screenshot to Discord on the configured interval.
- Runs a watchdog every few seconds to keep Roblox foreground.
- When automatic game joining is enabled, it requests game `1730877806` with the Roblox direct deep-link format. Roblox documents `roblox://placeId=<id>` as the direct-to-app format.
- The game watchdog will not repeatedly issue the same join request while Roblox is still loading. A successful request enters a configurable join-pending window (90 seconds by default).
- A game is considered positively active when the target `placeId` is visible in the current Android ActivityRecord or when a configured Roblox game-runtime process is present (defaults include `free.nokaA:glview` and `free.nokaA:game`).
- Ctrl+C is handled as an immediate shutdown signal. Rooted Android commands run without terminal stdin, in their own process groups, and are terminated as a group during shutdown.

## Important limitation

Android activity names are not sufficient by themselves to distinguish the Roblox home/menu from an experience on this client. The watchdog therefore does not treat `ActivityNativeMain` alone as proof of being inside the target game. The process suffix list and join grace/retry windows are configurable in `config.json`.

## Start

```bash
./start.sh
```

Press `Ctrl+C` once to stop. The terminal should immediately show a shutdown line followed by the monitor cleanup message.
