# CloudPhone Monitor

A rooted Android/Termux monitor for a cloud phone running Roblox (or a custom Roblox launcher package).

## What this patch does

- Checks whether the configured launcher package is running.
- Launches it automatically if it is not running.
- Every 5 minutes (configurable):
  - CPU usage
  - RAM usage
  - battery level / temperature / charging state
  - device uptime
  - storage usage
  - screen state
  - foreground package/activity
  - launcher PID / process state
  - logged-in Roblox username, display name and user ID when available
  - screenshot of the Android screen
- Sends the report + screenshot to a Discord webhook.
- Keeps the code split into modules so a Discord bot or another command/control layer can be added later.

## Assumptions

This is intended for a rooted Android device running Termux. Root is used to read another app's private data and to invoke Android shell commands from Termux.

The configured package defaults to `free.nokaA`.

## Install

```sh
pkg update
pkg install python
cd ~/cloudphone-monitor
python -m pip install -r requirements.txt
```

Optional: if `termux-api` / Termux:API is installed, the monitor can fall back to `termux-screenshot`, but the primary screenshot path uses Android `screencap` through root.

## Configure

Edit `config.json`.

For the Discord webhook, the recommended approach is an environment variable:

```sh
export CLOUDPHONE_DISCORD_WEBHOOK='https://discord.com/api/webhooks/REPLACE_ME'
```

Then leave `webhook_url` blank in `config.json`.

You can also put the URL directly in the config file, but do not commit that file to a public repository.

## Run

```sh
cd ~/cloudphone-monitor
python main.py
```

The first report is sent immediately, then the monitor repeats every 300 seconds by default.

To run in the background:

```sh
nohup python main.py >> monitor.log 2>&1 &
```

## Quick diagnostics

```sh
su -c 'pm path free.nokaA'
su -c 'pidof free.nokaA'
su -c 'monkey -p free.nokaA 1'
su -c 'screencap -p /data/local/tmp/cloudphone-monitor-test.png'
```

If `pidof free.nokaA` returns nothing even while the launcher is visible, the package may use a different process name. In that case set `process_name` in `config.json` to the real process name.

## Account detection

The monitor checks the Android app data under:

- `/data/user/<user-id>/<package>/files/appData/LocalStorage/appStorage.json`
- `/data/user/<user-id>/<package>/shared_prefs/prefs.xml`
- `/data/data/<package>/...` as a compatibility fallback

For standard Roblox Android storage, the username/user ID/display name are commonly stored in `appStorage.json`, with a second copy in `prefs.xml`. The monitor only reports identity fields; it deliberately does not report credentials, cookies, advertising IDs, or tokens.

## Project layout

```text
cloudphone-monitor/
├── config.json
├── main.py
├── requirements.txt
├── start.sh
└── cloudphone_monitor/
    ├── __init__.py
    ├── android.py
    ├── config.py
    ├── discord_reporter.py
    ├── metrics.py
    ├── monitor.py
    └── roblox.py
```

## Future Discord bot integration

The monitor's collection/reporting interfaces are separated from the loop. A future Discord bot can import the same collectors and add commands such as status, restart launcher, force report, or screenshot without changing the Android collection code.
