from __future__ import annotations

import os
import re
import subprocess
import time
from pathlib import Path
from typing import Sequence


class AndroidCommandError(RuntimeError):
    pass


def run_root(command: str | Sequence[str], timeout: int = 15, check: bool = False) -> subprocess.CompletedProcess[str]:
    if isinstance(command, str):
        shell_command = command
    else:
        shell_command = " ".join(_shell_quote(item) for item in command)

    result = subprocess.run(
        ["su", "-c", shell_command],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )
    if check and result.returncode != 0:
        raise AndroidCommandError(result.stderr.strip() or result.stdout.strip() or f"root command failed: {shell_command}")
    return result


def _shell_quote(value: str) -> str:
    return "'" + value.replace("'", "'\\''") + "'"


def root_available() -> bool:
    try:
        result = run_root("id", timeout=5)
        return result.returncode == 0 and "uid=0" in result.stdout
    except (OSError, subprocess.SubprocessError):
        return False


def package_installed(package: str) -> bool:
    result = run_root(["pm", "path", package], timeout=10)
    return result.returncode == 0 and "package:" in result.stdout


def process_pids(process_name: str, package: str | None = None) -> list[int]:
    names = [process_name]
    if package and package not in names:
        names.append(package)
    pids: set[int] = set()
    for name in names:
        result = run_root(["pidof", name], timeout=5)
        if result.returncode == 0:
            for token in result.stdout.split():
                try:
                    pids.add(int(token))
                except ValueError:
                    pass
    return sorted(pids)


def process_running(process_name: str, package: str | None = None) -> bool:
    return bool(process_pids(process_name, package))


def launch_package(package: str, method: str = "monkey") -> tuple[bool, str]:
    if method == "am_start_package":
        result = run_root(["am", "start", "-W", "-a", "android.intent.action.MAIN", "-c", "android.intent.category.LAUNCHER", "-p", package], timeout=20)
    else:
        # monkey is intentionally used here because the exact launcher Activity
        # is not known for a custom package.
        result = run_root(["monkey", "-p", package, "-c", "android.intent.category.LAUNCHER", "1"], timeout=20)
    ok = result.returncode == 0 and ("Error" not in result.stdout and "Exception" not in result.stdout)
    return ok, (result.stdout + result.stderr).strip()


def foreground_info() -> dict[str, str]:
    # `dumpsys activity activities` varies substantially between Android versions.
    # Try several known forms and also `cmd activity get-top-activity`.
    results = [
        run_root("dumpsys activity activities", timeout=10),
        run_root("dumpsys activity top", timeout=10),
        run_root("cmd activity get-top-activity", timeout=10),
    ]
    text = "\n".join(r.stdout + "\n" + r.stderr for r in results)

    patterns = [
        r"mResumedActivity:.*?\b([A-Za-z0-9_.$]+)/(?:[A-Za-z0-9_.$]+)",
        r"topResumedActivity=ActivityRecord\{[^ ]+ [^ ]+ ([A-Za-z0-9_.$]+)/([A-Za-z0-9_.$]+)",
        r"ResumedActivity:.*?\b([A-Za-z0-9_.$]+)/(?:[A-Za-z0-9_.$]+)",
        r"(?:^|\s)([A-Za-z0-9_.$]+)/([A-Za-z0-9_.$]+)\s*$",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.MULTILINE)
        if match:
            package = match.group(1)
            activity = match.group(2) if match.lastindex and match.lastindex >= 2 else "unknown"
            return {"package": package, "activity": activity}

    return {"package": "unknown", "activity": "unknown"}


def app_state(package: str, process_name: str) -> dict[str, object]:
    foreground = foreground_info()
    pids = process_pids(process_name, package)
    process_exists = bool(pids)
    is_foreground = foreground.get("package") == package
    return {
        "process_exists": process_exists,
        "process_pids": pids,
        "foreground": is_foreground,
        "foreground_package": foreground.get("package"),
        "foreground_activity": foreground.get("activity"),
        # For a cloudphone watchdog, 'running' means the requested app is actually
        # the foreground app, not merely a background Android process.
        "running": is_foreground,
    }


def screen_on() -> bool | None:
    result = run_root("dumpsys power", timeout=10)
    text = result.stdout + "\n" + result.stderr
    matches = re.findall(r"(?:mWakefulness=|Display Power: state=)([A-Za-z]+)", text)
    if matches:
        state = matches[-1].upper()
        if state in {"AWAKE", "ON"}:
            return True
        if state in {"ASLEEP", "OFF", "DOZING"}:
            return False
    return None


def battery_info() -> dict[str, object]:
    result = run_root("dumpsys battery", timeout=10)
    text = result.stdout + "\n" + result.stderr

    def find_int(*names: str) -> int | None:
        for name in names:
            match = re.search(rf"^\s*{re.escape(name)}\s*:\s*(-?\d+)", text, flags=re.MULTILINE)
            if match:
                return int(match.group(1))
        return None

    level = find_int("level")
    temp_tenths = find_int("temperature")
    status = find_int("status")
    plugged = find_int("plugged")

    return {
        "level_percent": level,
        "temperature_c": round(temp_tenths / 10.0, 1) if temp_tenths is not None else None,
        "status_code": status,
        "plugged_code": plugged,
    }


def uptime_seconds() -> float | None:
    try:
        with open("/proc/uptime", "r", encoding="ascii") as handle:
            return float(handle.read().split()[0])
    except (OSError, ValueError, IndexError):
        return None


def storage_info(path: str = "/data") -> dict[str, object]:
    try:
        stat = os.statvfs(path)
        total = stat.f_blocks * stat.f_frsize
        free = stat.f_bavail * stat.f_frsize
        used = total - free
        return {
            "path": path,
            "total_bytes": total,
            "used_bytes": used,
            "free_bytes": free,
            "used_percent": round((used / total) * 100, 2) if total else None,
        }
    except OSError:
        return {"path": path, "total_bytes": None, "used_bytes": None, "free_bytes": None, "used_percent": None}


def thermal_zones() -> list[dict[str, object]]:
    zones: list[dict[str, object]] = []
    base = Path("/sys/class/thermal")
    if not base.exists():
        return zones

    for temp_file in sorted(base.glob("thermal_zone*/temp")):
        try:
            raw = temp_file.read_text(encoding="ascii").strip()
            milli_c = int(raw)
            value_c = milli_c / 1000.0
            zones.append({"zone": temp_file.parent.name, "celsius": round(value_c, 1)})
        except (OSError, ValueError):
            continue
    return zones


def screenshot(output_path: str, max_bytes: int = 18_000_000) -> tuple[bool, str]:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    result = run_root(["screencap", "-p", str(path)], timeout=20)
    if result.returncode != 0 or not path.exists():
        return False, (result.stdout + result.stderr).strip()

    # Make the root-created screenshot readable by the unprivileged Termux process.
    run_root(["chmod", "0644", str(path)], timeout=5)

    size = path.stat().st_size
    if size <= 0:
        return False, "screencap produced an empty file"
    if size > max_bytes:
        return False, f"screenshot is {size} bytes, over configured limit {max_bytes}"

    return True, ""
