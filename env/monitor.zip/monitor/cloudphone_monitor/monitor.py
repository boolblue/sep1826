from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import android
from .config import Config, resolve_webhook_url
from .discord_reporter import DiscordReporter
from .metrics import collect_system_metrics
from .roblox import get_account


class CloudPhoneMonitor:
    def __init__(self, config: Config):
        self.config = config
        self.logger = logging.getLogger("cloudphone-monitor")
        self.runtime_dir = Path(config.runtime.temp_dir)

    def ensure_launcher(self) -> dict[str, Any]:
        package = self.config.app.package
        process = self.config.app.process_name
        installed = android.package_installed(package)
        state = android.app_state(package, process) if installed else {
            "process_exists": False, "process_pids": [], "foreground": False,
            "foreground_package": "unknown", "foreground_activity": "unknown",
            "running": False,
        }
        launch_attempted = False
        launch_output = ""

        # A background process is NOT considered a healthy running instance.
        # Launch whenever the target package is not actually foreground.
        if installed and not state["running"] and self.config.app.auto_launch:
            launch_attempted = True
            ok, launch_output = android.launch_package(package, self.config.app.launch_method)
            if ok:
                time.sleep(max(0, self.config.app.launch_grace_seconds))
            state = android.app_state(package, process)

        return {
            "package": package,
            "installed": installed,
            "running": bool(state["running"]),
            "process_exists": bool(state["process_exists"]),
            "process_pids": state["process_pids"],
            "foreground": bool(state["foreground"]),
            "foreground_package": state["foreground_package"],
            "foreground_activity": state["foreground_activity"],
            "launch_attempted": launch_attempted,
            "launch_output": launch_output[-500:],
        }

    def collect_report(self) -> tuple[dict[str, Any], Path | None]:
        app = self.ensure_launcher()
        metrics = collect_system_metrics(
            self.config.monitor.cpu_sample_seconds,
            self.config.app.package,
            self.config.app.process_name,
        )
        account = get_account(self.config.app.package)

        timestamp = datetime.now(timezone.utc).isoformat()
        payload = {
            "timestamp": timestamp,
            "app": app,
            "account": account,
            "metrics": metrics,
        }

        screenshot_path: Path | None = None
        if self.config.monitor.screenshot_enabled:
            self.runtime_dir.mkdir(parents=True, exist_ok=True)
            screenshot_path = self.runtime_dir / "latest.png"
            ok, detail = android.screenshot(str(screenshot_path), self.config.monitor.max_screenshot_bytes)
            if not ok:
                self.logger.warning("Screenshot failed: %s", detail)
                screenshot_path = None

        return payload, screenshot_path

    def send(self, payload: dict[str, Any], screenshot_path: Path | None) -> None:
        webhook_url = resolve_webhook_url(self.config.discord)
        if not webhook_url:
            raise RuntimeError(
                "Discord webhook is not configured. Set discord.webhook_url or the configured environment variable."
            )

        reporter = DiscordReporter(
            webhook_url=webhook_url,
            username=self.config.discord.username,
            avatar_url=self.config.discord.avatar_url,
            timeout=self.config.monitor.request_timeout_seconds,
        )
        reporter.send_report(
            payload,
            screenshot_path=screenshot_path,
            content=self.config.discord.content,
            mention=self.config.discord.mention,
        )

    def run_once(self) -> None:
        payload, screenshot_path = self.collect_report()
        self.logger.info(
            "status package=%s running=%s username=%s cpu=%s ram=%s",
            payload["app"]["package"],
            payload["app"]["running"],
            payload["account"].get("username"),
            payload["metrics"].get("cpu_percent"),
            payload["metrics"].get("memory", {}).get("used_percent"),
        )
        self.send(payload, screenshot_path)

    def loop(self) -> None:
        self.logger.info("CloudPhone Monitor starting for %s", self.config.app.package)
        if not android.root_available():
            raise RuntimeError("Root is not available to Termux (su -c id did not return uid=0).")

        while True:
            started = time.monotonic()
            try:
                self.run_once()
                self.logger.info("Report sent successfully")
            except Exception:
                self.logger.exception("Monitor cycle failed")

            elapsed = time.monotonic() - started
            delay = max(1.0, self.config.monitor.interval_seconds - elapsed)
            self.logger.info("Next cycle in %.1f seconds", delay)
            time.sleep(delay)
