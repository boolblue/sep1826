from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import requests


class DiscordReporter:
    def __init__(self, webhook_url: str, username: str, avatar_url: str = "", timeout: int = 20):
        self.webhook_url = webhook_url
        self.username = username
        self.avatar_url = avatar_url
        self.timeout = timeout

    def send_report(self, payload: dict[str, Any], screenshot_path: Path | None = None, content: str = "", mention: str = "") -> None:
        if not self.webhook_url:
            raise ValueError("Discord webhook URL is not configured")

        embeds = [self._embed(payload)]
        data = {
            "username": self.username,
            "embeds": embeds,
            "allowed_mentions": {"parse": ["users", "roles"] if mention else []},
        }
        if self.avatar_url:
            data["avatar_url"] = self.avatar_url
        if content or mention:
            data["content"] = (mention + " " + content).strip()

        files = None
        opened = None
        try:
            if screenshot_path is not None and screenshot_path.exists():
                opened = screenshot_path.open("rb")
                files = {"files[0]": (screenshot_path.name, opened, "image/png")}
                response = requests.post(
                    self.webhook_url,
                    data={"payload_json": json.dumps(data, ensure_ascii=False)},
                    files=files,
                    timeout=self.timeout,
                )
            else:
                response = requests.post(self.webhook_url, json=data, timeout=self.timeout)

            response.raise_for_status()
        finally:
            if opened:
                opened.close()

    @staticmethod
    def _fmt_bytes(value: Any) -> str:
        if value is None:
            return "n/a"
        value = float(value)
        units = ["B", "KB", "MB", "GB", "TB"]
        idx = 0
        while value >= 1024 and idx < len(units) - 1:
            value /= 1024
            idx += 1
        return f"{value:.1f} {units[idx]}"

    @classmethod
    def _embed(cls, p: dict[str, Any]) -> dict[str, Any]:
        app = p.get("app", {})
        m = p.get("metrics", {})
        mem = m.get("memory", {})
        bat = m.get("battery", {})
        storage = m.get("storage", {})
        fg = m.get("foreground", {})
        account = p.get("account", {})

        description = [
            f"**Launcher:** `{app.get('package', 'unknown')}` — {'RUNNING' if app.get('running') else 'NOT RUNNING'}",
            f"**CPU:** `{m.get('cpu_percent', 'n/a')}%`",
            f"**RAM:** `{mem.get('used_percent', 'n/a')}%` used ({cls._fmt_bytes(mem.get('used_bytes'))} / {cls._fmt_bytes(mem.get('total_bytes'))})",
            f"**Launcher PID:** `{m.get('launcher_pid', 'n/a')}`  |  **Process CPU:** `{m.get('launcher_process_cpu_percent', 'n/a')}%`",
            f"**Battery:** `{bat.get('level_percent', 'n/a')}%`  |  **Battery temp:** `{bat.get('temperature_c', 'n/a')}°C`",
            f"**Storage /data:** `{storage.get('used_percent', 'n/a')}%` used",
            f"**Screen:** `{('ON' if m.get('screen_on') else 'OFF') if m.get('screen_on') is not None else 'UNKNOWN'}`",
            f"**Foreground:** `{fg.get('package', 'unknown')}/{fg.get('activity', 'unknown')}`",
            f"**Account:** `{account.get('username') or 'unknown'}`"
            + (f"  |  `{account.get('display_name')}`" if account.get("display_name") else "")
            + (f"  |  ID `{account.get('user_id')}`" if account.get("user_id") else ""),
        ]

        return {
            "title": "CloudPhone Monitor",
            "description": "\n".join(description),
            "timestamp": p.get("timestamp"),
        }
