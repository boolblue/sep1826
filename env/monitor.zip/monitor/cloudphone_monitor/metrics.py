from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass
from typing import Any

from . import android


@dataclass
class ProcStat:
    total: int
    idle: int


def _read_cpu_stat() -> ProcStat | None:
    # Read through root as well. Some Android/Termux combinations expose a
    # restricted or virtualized /proc to Termux, while `su` sees the host CPU.
    first = ""
    try:
        result = android.run_root("head -n 1 /proc/stat", timeout=5)
        first = result.stdout.strip()
    except Exception:
        pass
    if not first:
        try:
            with open("/proc/stat", "r", encoding="ascii") as handle:
                first = handle.readline()
        except OSError:
            return None

    fields = first.split()
    if not fields or fields[0] != "cpu" or len(fields) < 5:
        return None
    try:
        values = [int(value) for value in fields[1:]]
    except ValueError:
        return None

    # cpu user nice system idle iowait irq softirq steal ...
    idle = values[3] + (values[4] if len(values) > 4 else 0)
    return ProcStat(total=sum(values), idle=idle)


def cpu_usage_percent(sample_seconds: float = 1.0) -> float | None:
    before = _read_cpu_stat()
    if before is None:
        return None
    time.sleep(max(0.1, sample_seconds))
    after = _read_cpu_stat()
    if after is None:
        return None

    total_delta = after.total - before.total
    idle_delta = after.idle - before.idle
    if total_delta <= 0:
        return None
    value = (total_delta - idle_delta) / total_delta * 100.0
    return round(max(0.0, min(100.0, value)), 2)


def memory_info() -> dict[str, Any]:
    data: dict[str, int] = {}
    try:
        with open("/proc/meminfo", "r", encoding="ascii") as handle:
            for line in handle:
                parts = line.split(":", 1)
                if len(parts) != 2:
                    continue
                key, rest = parts
                match = re.search(r"(\d+)", rest)
                if match:
                    data[key] = int(match.group(1)) * 1024
    except OSError:
        return {"total_bytes": None, "available_bytes": None, "used_bytes": None, "used_percent": None}

    total = data.get("MemTotal")
    available = data.get("MemAvailable")
    used = total - available if total is not None and available is not None else None
    return {
        "total_bytes": total,
        "available_bytes": available,
        "used_bytes": used,
        "used_percent": round((used / total) * 100.0, 2) if used is not None and total else None,
    }


def load_average() -> list[float] | None:
    try:
        values = os.getloadavg()
        return [round(value, 2) for value in values]
    except OSError:
        return None


def process_cpu_percent(pid: int) -> float | None:
    # Single-snapshot process CPU is intentionally omitted. Accurate per-process CPU
    # requires sampling /proc/<pid>/stat against system jiffies. The helper below does it.
    try:
        def read() -> tuple[int, int]:
            result = android.run_root(["cat", f"/proc/{pid}/stat"], timeout=5)
            if result.returncode != 0 or not result.stdout.strip():
                raise OSError(result.stderr.strip() or "unable to read process stat")
            fields = result.stdout.split()
            proc_ticks = int(fields[13]) + int(fields[14])
            system = _read_cpu_stat()
            if system is None:
                raise ValueError
            return proc_ticks, system.total

        proc1, total1 = read()
        time.sleep(0.2)
        proc2, total2 = read()
        proc_delta = proc2 - proc1
        total_delta = total2 - total1
        cpu_count = os.cpu_count() or 1
        if proc_delta < 0 or total_delta <= 0:
            return None
        return round((proc_delta / total_delta) * cpu_count * 100.0, 2)
    except (OSError, ValueError, IndexError):
        return None


def collect_system_metrics(cpu_sample_seconds: float, package: str, process_name: str) -> dict[str, Any]:
    pids = android.process_pids(process_name, package)
    launcher_pid = pids[0] if pids else None

    return {
        "cpu_percent": cpu_usage_percent(cpu_sample_seconds),
        "memory": memory_info(),
        "load_average": load_average(),
        "launcher_process_cpu_percent": process_cpu_percent(launcher_pid) if launcher_pid else None,
        "launcher_pid": launcher_pid,
        "uptime_seconds": android.uptime_seconds(),
        "battery": android.battery_info(),
        "storage": android.storage_info("/data"),
        "thermal_zones": android.thermal_zones(),
        "screen_on": android.screen_on(),
        "foreground": android.foreground_info(),
    }
