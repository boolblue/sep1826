# CloudPhone Monitor v0.1.3

A rooted Android/Termux monitor for a cloud phone running Roblox (or a custom Roblox launcher package).

## v0.1.3 changes

- Uses the configured launcher Activity instead of assuming the package can be opened with Monkey.
- Default launcher Activity for this cloudphone: `com.roblox.client.startup.LauncherAliasMain`.
- Falls back to Android's normal launcher intent / Monkey when the explicit component cannot be started.
- Foreground detection only trusts resumed/top-resumed/focused activity lines, avoiding false positives from historical task entries.
- CPU usage no longer depends on `os.getloadavg()` (which is not present in some Termux Python builds). Load average is read from `/proc/loadavg`.
- CPU percentage uses `/proc/stat` sampling and has a `top` fallback.
- Keeps account extraction and device collection modular for future Discord bot commands.

## Install

```sh
pkg update
pkg install python
cd ~/cloudphone-monitor
python -m pip install -r requirements.txt
```

## Configure

```json
"app": {
  "package": "free.nokaA",
  "process_name": "free.nokaA",
  "launcher_activity": "com.roblox.client.startup.LauncherAliasMain",
  "auto_launch": true,
  "launch_method": "explicit_activity"
}
```

For Discord, use an environment variable rather than committing the webhook:

```sh
export CLOUDPHONE_DISCORD_WEBHOOK='https://discord.com/api/webhooks/REPLACE_ME'
```

## Run

```sh
cd ~/cloudphone-monitor
python main.py
```

## Launch diagnostics

```sh
su -c 'pm path free.nokaA'
su -c 'pidof free.nokaA'
su -c '/system/bin/am start -W -n free.nokaA/com.roblox.client.startup.LauncherAliasMain'
su -c 'dumpsys activity activities | grep -E "mResumedActivity|topResumedActivity"'
su -c 'dumpsys window windows | grep -E "mCurrentFocus|mFocusedApp"'
```

## Monitoring

Every 5 minutes by default the monitor reports CPU, RAM, load average, battery, temperatures, storage, uptime, foreground package/activity, launcher process information, Roblox account identity when available, and a screenshot. The launcher is checked before each report and is automatically started when it is not the current foreground package.

## Security

Do not put a real Discord webhook in source control. If a webhook has been exposed in a script or chat, rotate/revoke that webhook in Discord and create a new one.
